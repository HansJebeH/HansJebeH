const menunya = ` 

┏━━⊱ ❍ 𝗢𝗪𝗡𝗘𝗥𝗠𝗘𝗡𝗨  ❍
┣❏.Self
┣❏.Public
┣❏.Restart
┣❏.Shutdown
┣❏.CreateGc
┣❏.Promote
┣❏.Demote
┣❏.ListPc
┣❏.Block 628xx
┣❏.Unblock 628xxx
┣❏.SetPpBot
┣❏.AntiCall (On/Off)
┣❏.AddPrem
┣❏.DelPrem
┣❏.ListPrem 
┣❏.join
┣❏
┗━━⊱

┏━━⊱ ❍ 𝗣𝗔𝗡𝗘𝗟𝗠𝗘𝗡𝗨  ❍
┣❏.AddUsr
┣❏.DelUsr
┣❏.ListSrv
┣❏.AddSrv
┣❏.DelSrv
┣❏.createadmin
┣❏
┗━━⊱
┏━━⊱ ❍ 𝗠𝗘𝗡𝗨𝗥𝗘𝗦𝗘𝗟𝗟𝗘𝗥  ❍
┣❏.1gb,username,628xxx
┣❏.2gb,username,628xxx
┣❏.3gb,username,628xxx
┣❏.4gb,username,628xxx
┣❏.5gb,username,628xxx
┣❏.6gb,username,628xxx
┣❏.7gb,username,628xxx
┣❏.8gb,username,628xxx
┣❏.9gb,username,628xxx
┣❏.10gb,username,628xxx
┣❏.unli [ Khusus Owner ]
┗━━⊱

┏━━⊱ ❍ 𝗣𝗨𝗦𝗛𝗞𝗢𝗡𝗧𝗔𝗞𝗠𝗘𝗡𝗨 ❍
┣❏.PushKontak
┣❏.PushKontakv2 (ViaId)
┣❏.GetIdGc
┣❏.ListIdGc
┣❏.PushUser
┗━━⊱

┏━━⊱ ❍ *BUG ATTACK GROUP v1* ❍
┣❏.killgc *linkgc|jumlah*
┣❏.santetgc *linkgc|jumlah*
┣❏.gcwakwaw *linkgc|jumlah*
┣❏.togc *linkgc|jumlah*
┣❏.matigc *linkgc|jumlah*
┣❏.kuygc *linkgc|jumlah*
┣❏.attackgc *linkgc|jumlah*
┣❏.mampusgc *linkgc|jumlah*
┣❏.gasgc *linkgc|jumlah*
┣❏.ampasgc *linkgc|jumlah*
┣❏.bahayagc *linkgc|jumlah*
┣❏.hatihatigc *linkgc|jumlah*
┣❏.crashgc *linkgc|jumlah*
┣❏.stuckgc *linkgc|jumlah*
┣❏.ganasgc *linkgc|jumlah*
┗━━⊱

┏━━⊱❍ *BUG ATTACK GROUP v2* ❍
┣❏.buggc *idgroup|jumlah*
┣❏.shootgc *idgroup|jumlah*
┣❏.dorrgc *idgroup|jumlah*
┣❏.attackgc1 *idgroup|jumlah*
┣❏.meninggalgc *idgroup|jumlah*
┣❏.matigc1 *idgroup|jumlah*
┣❏.seranggc *idgroup|jumlah*
┣❏.bomgc *idgroup|jumlah*
┣❏.ledakangc *idgroup|jumlah*
┣❏.atomgc *idgroup|jumlah*
┣❏.hancurgc *idgroup|jumlah*
┣❏.bugzirgc *idgroup|jumlah*
┣❏.stuckgc2 *idgroup|jumlah*
┣❏.baugc *idgroup|jumlah*
┣❏.ultigc *idgroup|jumlah*
┗━━⊱

┏━━⊱ ❍ *MENU BANNED* ❍
┣❏.call *nomor*
┣❏.out *nomor*
┣❏.verif *nomor*
┣❏.kenon *nomor*
┣❏.bannedv1 *nomor*
┣❏.bannedv2 *nomor*
┣❏.bannedv3 *nomor*
┣❏.bannedv4 *nomor*
┣❏.bannedv5 *nomor*
┣❏.bannedv6 *nomor*
┗━━⊱

┏━━⊱ ❍ *MENU UNBANNED* ❍
┣❏.unbannedv1 *nomor*
┣❏.unbannedv2 *nomor*
┣❏.unbannedv3 *nomor*
┣❏.unbannedv4 *nomor*
┣❏.unbannedv5 *nomor*
┗━━⊱

┏━━⊱ ❍ 𝗚𝗥𝗢𝗨𝗣𝗠𝗘𝗡𝗨  ❍
┣❏.Kick @
┣❏.Add +628xxx
┣❏.Linkgc
┣❏.Hidetag (Teks)
┣❏.TagAll (Teks)
┣❏.Antilink (On/Off)
┣❏.Gc (O/C Open/Close)
┣❏.Welcome (On/Off)
┣❏.Left (On/Off)
┣❏.SetPpGc
┣❏.SetDesk
┣❏.ListOnline
┣❏.SetSubject
┣❏.GetPp @
┗━━⊱

┏━━⊱ ❍ 𝗢𝗧𝗛𝗘𝗥𝗡𝗨  ❍
┣❏.Ai
┣❏.AiImage
┣❏.Stiker
┣❏.Smeme
┣❏.Tiktok (Link)
┣❏.Qc
┣❏.Ping
┣❏
┗━━⊱
𝗥𝗘𝗖𝗢𝗗𝗘 𝗕𝗬 𝗭𝗫𝗢𝗢`

exports.menunya = menunya