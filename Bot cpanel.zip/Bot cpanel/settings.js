const fs = require('fs')
const chalk = require('chalk')

///Gantinya Ngerti Kan Lu Kan dah Gede

global.domain = "https://zxoostore.mypannel.icu" // Isi Domain Lu
global.apikey = 'ptla_vBhgY485T58JYWp7ukW14KznwBwKz9qOQrhpVHWbBb7' // Isi Apikey Plta Lu
global.capikey = 'ptlc_Da6e9ZE1kJuov58K9e4hmY8ALiREuPW3eIhjr7yMVRX' // Isi Apikey Pltc Lu
global.aipikey = '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'
global.creAtor = "62857685850542@s.whatsapp.net"
global.owner = ['62857685850542']
global.ownerNumber = ["62857685850542@s.whatsapp.net"]
global.nomerOwner = "62857685850542"
global.namabotnya = 'ZxooBotz'
global.namaownernya = 'ZxooDev'
global.packname = '© Zxoo||+62857685850542🇲🇨\nI`m From Indonesia'
global.author = 'Wa : 62857685850542\nYT : zxooexalibur'
global.sessionName = 'session'
global.email = '-'
global.group = '-'
global.youtube = 'https://www.youtube.com/@zxoooxalibrs'
global.website = 'kaga ada'
global.github = 'https://github.com/'
global.nomorowner = 'https://wa.me/62857685850542'
global.region = 'I`m From Indonesia'
global.prefa = ['','!','.','#','-','•']
global.anticall = true
global.wm = "Subscribe YT *XieTy*"
global.mess = 
{
success: '```Success✅```',
admin: '```Fitur Khusus Admin Group!!!```',
botAdmin: '```Bot Harus Menjadi Admin Terlebih Dahulu!!!```',
owner: '```Fitur Khusus Owner Bot!!!```',
group: '```Fitur Digunakan Hanya Untuk Group!!!```',
private: '```Fitur Digunakan Hanya Untuk Private Chat!!!```',
banned: '*Kamu Telah Dibanned Untuk Menggunakan Bot Ini Untuk Membuka Banned Chat Owner .Owner*',
bot: '```Fitur Khusus Pengguna Nomor Bot!!!```',
premium: 'Maaf Sebelumya Kamu Belum Premium, Silahkan Chat Owner Untuk Beli Premium Ketik .Owner',
error: '```Mungkin Lagi Error Kak Harap Lapor Owner Biar Langsung Di Benerin🙏```',
wait: '```Waittt...```'
}

global.thumb = fs.readFileSync('./image/thumb.png')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.yellowBright(`Update File Terbaru ${__filename}`))
delete require.cache[file]
require(file)
})
